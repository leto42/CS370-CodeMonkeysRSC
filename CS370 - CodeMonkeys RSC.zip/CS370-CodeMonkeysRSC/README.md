# CS370-CodeMonkeysRSC

Random Song Chooser for CS 370 Project

User will choose a genre and then a random song that belongs to that category will appear with a YouTube video.
User has the option to favorite the song.
   
If the song is favorited, then the user has the option to be redirected to albumscreated by the same artist.
User can save the album and can view them in a different tab.
  
User can look/play songs that they favorited/saved previously.
